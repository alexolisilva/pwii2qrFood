package com.anl;

public class TesteMainALEX {

	public static void main(String[] args) {
		
		System.out.println("Funcioooonaaaaaa!!! Alex!!!");

	}

}
